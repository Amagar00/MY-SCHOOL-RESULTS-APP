const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');

function createWindow () {
  // Create the browser window.
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    title: "School Result Management System",
    icon: path.join(__dirname, 'assets/icon.png'), // Optional: Add an icon later
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  // Load your HTML file
  win.loadFile('index.html');

  // Remove the top menu bar (File, Edit, View) for a cleaner look
  // Menu.setApplicationMenu(null); 
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
